package com.usbank.evidencedataprovider.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class EvidenceApiCaller {

    @Value("${evidence.api.url}")
    private String evidenceApiUrl;

    @Autowired
    private RestTemplate restTemplate;

    public List<String> callEvidenceApi(){
        List<String> callResponse = (List<String>) this.restTemplate.postForEntity(this.evidenceApiUrl, this.getHttpEntity(), List.class);
        return callResponse;
    }

    private HttpEntity getHttpEntity(){
        HttpEntity httpEntity = new HttpEntity("", this.getHttpHeaders());
        return httpEntity;
    }

    private HttpHeaders getHttpHeaders(){
        HttpHeaders httpHeaders = new HttpHeaders();
        return httpHeaders;
    }
}
