package com.usbank.evidencedataprovider.controller;

import com.usbank.evidencedataprovider.model.responses.CompleteEvidenceDataResponse;
import com.usbank.evidencedataprovider.service.EDPService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/getEvidenceData")
public class EDPController {

    @Autowired
    EDPService edpService;

    @PostMapping("/complete")
    public ResponseEntity<CompleteEvidenceDataResponse> getComplete(){
        return ResponseEntity.ok().body(this.edpService.getCompleteEvidenceData());
    }
}
