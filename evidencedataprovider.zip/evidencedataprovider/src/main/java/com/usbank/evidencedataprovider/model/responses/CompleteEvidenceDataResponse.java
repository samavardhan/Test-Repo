package com.usbank.evidencedataprovider.model.responses;


import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CompleteEvidenceDataResponse {

    private Boolean exceptionOccurred;
    private String exceptionMessage;
    private List<String> completeEvidenceData;
}
