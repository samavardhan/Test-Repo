package com.usbank.evidencedataprovider.service;

import com.usbank.evidencedataprovider.model.responses.CompleteEvidenceDataResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EDPService {

    @Autowired
    private EvidenceApiCaller evidenceApiCaller;

    public CompleteEvidenceDataResponse getCompleteEvidenceData(){
        CompleteEvidenceDataResponse completeEvidenceDataResponse = new CompleteEvidenceDataResponse();
        try{
            completeEvidenceDataResponse.setCompleteEvidenceData(this.evidenceApiCaller.callEvidenceApi());
            completeEvidenceDataResponse.setExceptionOccurred(false);
        }catch (Exception e){
            completeEvidenceDataResponse.setExceptionOccurred(true);
            completeEvidenceDataResponse.setExceptionMessage(e.getMessage());
            e.printStackTrace();
        }
        return completeEvidenceDataResponse;
    }
}
