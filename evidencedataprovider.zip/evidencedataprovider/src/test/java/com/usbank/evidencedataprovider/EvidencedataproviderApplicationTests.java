package com.usbank.evidencedataprovider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvidencedataproviderApplicationTests {

	@Test
	void contextLoads() {
	}

}
